# Changelog

## 1.0.1 — UX polish and focused scope
- Reworked mobile navigation around five primary product areas.
- Added a premium Business Pulse dashboard hierarchy.
- Added focused Chronicle, Operations, Insights, and AI Analyst experiences.
- Improved spacing, card geometry, typography hierarchy, and mobile usability.
- Added a focused product scope to prevent feature sprawl before production hardening.
- Clarified non-negotiable production quality gates.

## 1.0.0
- Established Android, backend, database, security, architecture and documentation foundations.
