# BizChronicle AI 1.0 Architecture

```text
Android App (Kotlin + Jetpack Compose)
        |
        | authenticated HTTPS
        v
Backend API
        |
        +---- PostgreSQL / Supabase
        |
        +---- AI Provider (server-side)
        |
        +---- Chronicle + Analytics services
```

## Core domain
Businesses are the tenant boundary. Users become members of businesses with explicit roles. Sales, expenses, products, customers, inventory movements and events belong to a business.

## Chronicle principle
Every important mutation should create a structured business event. The event is an immutable business-memory record that can later be queried by analytics and AI.

## AI principle
The AI layer receives only authorized business context. Answers must distinguish recorded facts from interpretation and must not fabricate missing values.
