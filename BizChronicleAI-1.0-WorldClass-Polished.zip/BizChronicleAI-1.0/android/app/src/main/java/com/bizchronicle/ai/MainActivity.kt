package com.bizchronicle.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Ink = Color(0xFF10231D)
private val Brand = Color(0xFF0D6B55)
private val Bg = Color(0xFFF5F7F4)
private val Muted = Color(0xFF64736D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BizChronicleApp() }
    }
}

private enum class Screen(val label: String) {
    HOME("Home"), CHRONICLE("Chronicle"), OPERATIONS("Operations"), INSIGHTS("Insights"), AI("AI")
}

@Composable
fun BizChronicleApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Brand, background = Bg, surface = Color.White)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    Screen.entries.forEach { item ->
                        NavigationBarItem(
                            selected = screen == item,
                            onClick = { screen = item },
                            icon = { Text(if (screen == item) "●" else "○", color = if (screen == item) Brand else Muted) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) { ScreenContent(screen) }
        }
    }
}

@Composable
private fun ScreenContent(screen: Screen) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("BizChronicle AI", color = Brand, fontWeight = FontWeight.Bold)
                    Text(screen.label, style = MaterialTheme.typography.headlineMedium, color = Ink, fontWeight = FontWeight.Bold)
                }
                Surface(shape = RoundedCornerShape(50), color = Brand.copy(alpha = .10f)) { Text("BC", Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Brand, fontWeight = FontWeight.Bold) }
            }
        }
        when (screen) {
            Screen.HOME -> Home()
            Screen.CHRONICLE -> Chronicle()
            Screen.OPERATIONS -> Operations()
            Screen.INSIGHTS -> Insights()
            Screen.AI -> Analyst()
        }
    }
}

@Composable private fun Home() {
    itemBlock {
        Text("Business Pulse", style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Metric("Revenue", "KSh 48,620", "↑ 12.4%")
            Metric("Profit", "KSh 12,840", "↑ 8.7%")
            Metric("Orders", "126", "↑ 14")
            Metric("Stock alerts", "7", "Needs action")
        }
    }
    itemBlock {
        SectionCard("AI Briefing") {
            Text("Sales are above the comparison period. Flour is below its reorder level and deserves attention.", color = Ink)
            Spacer(Modifier.height(12.dp)); Button(onClick = {}) { Text("Open AI Analyst") }
        }
    }
    itemBlock {
        SectionCard("Latest Chronicle") {
            Event("Sale recorded", "KSh 3,450 · 2 min ago")
            Event("Inventory updated", "Flour · 8 units remaining")
            Event("Expense recorded", "Transport · KSh 1,200")
        }
    }
}

@Composable private fun Chronicle() {
    itemBlock { SectionCard("Business memory") {
        Event("14:20", "Sale recorded · KSh 3,450")
        Event("13:48", "Inventory updated · Flour 8 units")
        Event("12:10", "Customer added · Jane W.")
        Event("10:35", "Expense recorded · KSh 1,800")
    } }
}

@Composable private fun Operations() {
    itemBlock { SectionCard("Core operations") {
        ActionRow("Sales", "Record and review transactions")
        ActionRow("Inventory", "Stock, movements and reorder levels")
        ActionRow("Customers", "Purchase history and relationships")
        ActionRow("Expenses", "Track and categorize spending")
        ActionRow("Suppliers", "Purchases and supplier records")
    } }
}

@Composable private fun Insights() {
    itemBlock { SectionCard("Business intelligence") {
        ActionRow("Revenue trend", "Compare periods and identify changes")
        ActionRow("Margin watch", "Monitor profitability movement")
        ActionRow("Inventory risk", "Find products approaching reorder levels")
        ActionRow("Customer activity", "Understand frequency and value")
        ActionRow("Reports", "Generate management-ready reports")
    } }
}

@Composable private fun Analyst() {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf<String?>(null) }
    itemBlock { SectionCard("Ask your business") {
        Text("Ask questions using your recorded business data.", color = Muted)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = question, onValueChange = { question = it }, singleLine = false,
            placeholder = { Text("Why did profit change this month?") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Button(onClick = { answer = "Your question is ready for grounded analysis from the business data." }, enabled = question.isNotBlank()) { Text("Analyze") }
        answer?.let { Spacer(Modifier.height(12.dp)); Text(it, color = Ink, fontWeight = FontWeight.Medium) }
    } }
}

@Composable private fun Metric(label: String, value: String, change: String) {
    Card(Modifier.width(170.dp), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) {
        Text(label, color = Muted); Spacer(Modifier.height(6.dp)); Text(value, style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Bold); Text(change, color = Brand)
    } }
}

@Composable private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) { Text(title, style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); content() } }
}

@Composable private fun Event(title: String, detail: String) { Column(Modifier.padding(vertical = 7.dp)) { Text(title, color = Brand, fontWeight = FontWeight.SemiBold); Text(detail, color = Ink) } }
@Composable private fun ActionRow(title: String, detail: String) { Column(Modifier.fillMaxWidth().padding(vertical = 9.dp)) { Text(title, color = Ink, fontWeight = FontWeight.SemiBold); Text(detail, color = Muted) } }
@Composable private fun LazyListScope.itemBlock(content: @Composable () -> Unit) { item { content() } }
