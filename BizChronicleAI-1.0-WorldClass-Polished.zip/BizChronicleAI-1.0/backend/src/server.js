import 'dotenv/config';
import express from 'express';
import cors from 'cors';
const app = express(); app.use(cors()); app.use(express.json({limit:'1mb'}));
app.get('/health', (_req,res)=>res.json({ok:true,version:'1.0.0'}));
app.post('/api/ai', async (req,res)=>{
 const question = typeof req.body?.question === 'string' ? req.body.question.trim() : '';
 if(!question) return res.status(400).json({error:'question_required'});
 // Production implementation should authenticate the user, load only their business data,
 // then call the AI provider server-side. Never expose OPENAI_API_KEY to Android.
 res.json({answer:'AI endpoint ready. Connect authenticated business data and the server-side AI provider to enable grounded analysis.',grounded:false});
});
app.listen(process.env.PORT||3000,()=>console.log(`BizChronicle API listening on ${process.env.PORT||3000}`));
