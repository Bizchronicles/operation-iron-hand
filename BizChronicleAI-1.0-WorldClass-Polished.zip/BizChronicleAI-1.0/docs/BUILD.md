# Build checklist

1. Install Android Studio and a supported JDK.
2. Open the `android` directory.
3. Let Gradle sync and install the Android SDK requested by the project.
4. Run the app on an emulator or USB-debugging-enabled phone.
5. Configure the backend environment separately.
6. Apply `supabase/schema.sql` to the production database.
7. Add authentication and enforce business-level authorization in the API and database.
8. Connect the Android repository layer to the API.
9. Implement grounded AI retrieval and server-side AI calls.
10. Add tests, crash reporting, backups, monitoring and release signing before production release.
