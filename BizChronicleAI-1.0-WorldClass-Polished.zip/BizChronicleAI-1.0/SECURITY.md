# Security Baseline

1. Authenticate every protected API request.
2. Authorize access against the user's business membership and role.
3. Enforce business-level data isolation in the database.
4. Keep AI and database service credentials server-side only.
5. Validate and constrain all user input at the API boundary.
6. Rate-limit expensive AI endpoints.
7. Record security-relevant mutations in audit_logs.
8. Do not log secrets, passwords, tokens, or sensitive customer data.
9. Use HTTPS in production.
10. Back up the production database and test restoration.
11. Store Android session credentials using secure platform storage.
12. Protect release signing keys outside source control.
