# BizChronicle AI 1.0

BizChronicle AI is a business memory and intelligence platform designed to record important business events, organize operational data and turn that history into useful analysis.

## Package structure

- `android/` — native Android application foundation
- `backend/` — secure API boundary and AI integration point
- `supabase/` — PostgreSQL/Supabase schema foundation
- `preview/` — self-contained interactive visual reference
- `docs/` — build and transfer documentation
- `ARCHITECTURE.md` — system design
- `SECURITY.md` — security baseline
- `PROJECT_STATUS.md` — what is implemented and what remains
- `TRANSFER.md` — handoff checklist

## Open on a computer

1. Install Android Studio and a compatible JDK.
2. Open the `android/` directory as an Android Studio project.
3. Allow Android Studio to install/sync the required Android SDK and Gradle tooling.
4. Connect an Android device with USB debugging enabled or use an emulator.
5. Run the `app` configuration.
6. For a debug package, run the Gradle `assembleDebug` task.

The current environment used to package this handoff does not contain the Android SDK/Gradle toolchain, so a compiled APK is intentionally not represented as part of this source package.

## Backend setup

1. Copy `backend/.env.example` to `.env`.
2. Configure the production database and server settings.
3. Install Node.js dependencies with `npm install`.
4. Implement authenticated database access before exposing business endpoints.
5. Add the server-side AI provider configuration.
6. Run the API and verify `/health`.

## Database

Apply `supabase/schema.sql` to a PostgreSQL/Supabase project, then add and test the production authentication and row-level security policies appropriate to the deployment.

## Security

Private AI keys and database service-role credentials must remain server-side. Never commit `.env`, signing keys or secrets.

## Release

Before production, complete authentication, data access, transaction-safe business workflows, grounded AI, offline synchronization, automated testing, observability, privacy/security review and signed release builds.
