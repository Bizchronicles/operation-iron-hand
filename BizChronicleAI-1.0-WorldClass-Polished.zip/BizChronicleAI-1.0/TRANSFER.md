# BizChronicle AI 1.0 — Computer Transfer Checklist

## Copy
Extract the entire `BizChronicleAI-1.0` folder on the development computer. Do not separate the Android, backend, schema and documentation folders.

## Android
- Open `android/` in Android Studio
- Install requested SDK components
- Sync the project
- Run on an emulator or physical Android phone
- Build a debug APK

## Backend
- Open `backend/`
- Create `.env` from `.env.example`
- Add secrets locally only
- Install dependencies
- Start the API

## Database
- Create the production PostgreSQL/Supabase project
- Apply `supabase/schema.sql`
- Configure authentication
- Add and verify production row-level security policies

## Integration
- Point the Android app at the authenticated API
- Implement real repositories for sales, expenses, inventory, customers and Chronicle events
- Implement transaction-safe workflows
- Connect the AI Analyst to authorized business context on the server

## Release gate
Do not call the app production-ready until functional, security, synchronization, performance and device testing are complete. Generate a signed APK for direct installation and an AAB for Play Store distribution.
